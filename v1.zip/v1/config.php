<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'Chingon');
define('DB_PASSWORD', 'Chingon');
define('DB_HOST', 'localhost');
define('DB_NAME', 'Chingon')

?>